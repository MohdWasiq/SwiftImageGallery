import SwiftUI

struct ContentView: View {
    
    
    @ObservedObject var picsViewModel: PicsViewModel
    
    var body: some View {
        NavigationView {
            List(picsViewModel.picsModel, id: \.self) { model in
                VStack {
                    PicsImageView(url: model.downloadURL ?? "")
                        .frame(maxWidth: .infinity)
                    Text(model.author ?? "")
                        .font(.system(size: 20, weight: .bold, design: .rounded))
                        .padding()
                    Divider()
                }
            }
            .onAppear(perform: {
                picsViewModel.fetchPics()
            })
            .navigationTitle("Images")
        }
    }
}


struct PicsImageView: View {
    var url: String

    var body: some View {
        AsyncImage(url: URL(string: url)) { phase in
            switch phase {
            case .empty:
                ProgressView()
            case .success(let image):
                image.resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(maxWidth: .infinity, maxHeight: 250)
                    .cornerRadius(20)
                    .shadow(radius: 20)
            case .failure:
                Image(systemName: "photo")
            default:
                EmptyView()
            }
        }
        .frame(maxWidth: .infinity)
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(picsViewModel: PicsViewModel())
    }
}
