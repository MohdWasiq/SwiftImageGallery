

//  SwiftUIGalleryApp.swift
//  SwiftUIGallery
//
//  Created by Mohd Wasiq on 09/01/25.
//

import SwiftUI

@main
struct SwiftUIGalleryApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView(picsViewModel: PicsViewModel())
        }
    }
}
