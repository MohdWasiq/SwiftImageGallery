import Foundation
import SwiftUI

// Define a struct for your model that conforms to Decodable

 class PicsViewModel: ObservableObject {
     @Published var picsModel = [PicsModel]()  // Use the correct model type
    
    init() {
        fetchPics()
    }
    
    func fetchPics() {
        guard let url = URL(string: "https://picsum.photos/v2/list") else {
            print("Invalid URL")
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else {
                print("Error fetching data: \(error?.localizedDescription ?? "Unknown error")")
                return
            }
            
            do {
                let model = try JSONDecoder().decode([PicsModel].self, from: data)
                DispatchQueue.main.async {
                    self.picsModel = model
                }
            } catch {
                print("Error decoding JSON: \(error.localizedDescription)")
            }
        }.resume()
    }
}

