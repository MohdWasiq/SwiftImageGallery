//
//  PicsModel.swift
//  SwiftUIGallery
//
//  Created by Mohd Wasiq on 10/01/25.
//

import Foundation

struct PicsModel: Codable , Identifiable,Hashable {
    var id : String?
    var author : String?
    var downloadURL : String?
    
    enum CodingKeys : String , CodingKey {
        case id
        case author
        case downloadURL = "download_url"
    }
    
}
